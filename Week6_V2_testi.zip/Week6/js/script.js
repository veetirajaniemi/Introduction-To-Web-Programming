const jsonQuery = {
    "query": [
        {
            "code": "Vuosi",
            "selection": {
                "filter": "item",
                "values": [
                    "2000",
                    "2001",
                    "2002",
                    "2003",
                    "2004",
                    "2005",
                    "2006",
                    "2007",
                    "2008",
                    "2009",
                    "2010",
                    "2011",
                    "2012",
                    "2013",
                    "2014",
                    "2015",
                    "2016",
                    "2017",
                    "2018",
                    "2019",
                    "2020",
                    "2021"
                ]
            }
        },
        {
            "code": "Alue",
            "selection": {
                "filter": "item",
                "values": [ 
                    "SSS"
                ]
            }
        },
        {
            "code": "Tiedot",
            "selection": {
                "filter": "item",
                "values": [
                    "vaesto"
                ]
            }
        }
    ],
    "response": {
        "format": "json-stat2"
    }
}

const submitButton = document.getElementById("submit-data")
const inputArea = document.getElementById("input-area")
const dataButton = document.getElementById("add-data")
const curArea = document.getElementById("curArea")
let chart;

const chartData = {
    labels: null,
    datasets: null
}



const getData = async () => {
    const url = "https://statfin.stat.fi/PxWeb/api/v1/en/StatFin/synt/statfin_synt_pxt_12dy.px"

    const res = await fetch(url, {
        method: "POST",
        headers: {"content-type": "script/json"},
        body: JSON.stringify(jsonQuery)
    })
    if (!res.ok) {return}
    const data = await res.json()
    return data
}


const buildChart = async(areaName) => {
    const data = await getData()

    const years = Object.values(data.dimension.Vuosi.category.label) // vuodet
    const values = data.value // kaikki arvot
    const areaCode = Object.keys(data.dimension.Alue.category.label).find(key => data.dimension.Alue.category.label[key] === areaName)

    nVal = values.length
    nYrs = years.length
    nAreas = nVal/nYrs

    if (!areaCode) {
        return
    }
    
    const index = data.dimension.Alue.category.index[areaCode]

    
    let areaValues = []
    for (let i=0; i<nYrs ;i++) {
        areaValues.push(values[i*nAreas+index])
    }


    area = []
    area[0] = {
        name: areaName,
        values: areaValues
    }


    chartData.labels = years
    chartData.datasets = area

    curArea.innerText = area[0].name
    chart = new frappe.Chart("#chart", {
        title: "Population growth in " + area[0].name,
        data: chartData,
        type: "line",
        height: 450,
        color: '#eb5146'
    })
}

submitButton.addEventListener("click",() => {
    event.preventDefault()
    let areaName = inputArea.value.toLowerCase()
    if (areaName != "whole country") {
        console.log("jeejee")
        str = areaName.charAt(0).toUpperCase()
        areaName = str + areaName.slice(1)
    } else {
        areaName = areaName.toUpperCase()
    }
    buildChart(areaName) // oikea kaupungin nimi isolla kirjoitettuna

})

dataButton.addEventListener("click",() => {
    event.preventDefault()
    let values = chartData.datasets[0].values
    let name = chartData.datasets[0].name
    let yrs = chartData.labels
    let nVal = values.length
    let nYrs = yrs.length
    let deltaSum = 0


    for(let i = 1; i < nVal ; i++) {
        deltaSum += (values[i]-values[i-1])
    }

    let meanDelta = deltaSum / (nVal-1)
    let newVal = values[nVal-1] + meanDelta
    let newYr = parseInt(yrs[nYrs-1]) + 1
    
    values.push(newVal)
    yrs.push(newYr.toString())

    let newArea = []
    newArea[0] = {
        name: name,
        values: values
    }

    chartData.datasets = yrs
    chartData.datasets = newArea

    chart.data = chartData
    chart.update()

})


buildChart("WHOLE COUNTRY")

